<?php
    session_start();
    if(!isset($_SESSION['id'])){
        echo '<script>
        alert("로그인을 하십시오.");</script>';
        echo "<script>location.href='index.php'</script>";
        exit(); 
    }
?>
<?php
include "db_con.php";

$cname = $_POST['cname'];
$cexp = $_POST['cexp'];
$curl = $_POST['curl'];
$cadmin = $_POST['cadmin'];

 $sql = "select * from cafe where cname = '{$cname}'";
 $go = $db -> prepare($sql);
 $go -> execute();
 $re = $go -> fetch();
if($cname==NULL) {
    echo ("이름 입력하세요");
    exit();
} elseif($re['cname']==$cname){
    echo ("중복값");
    exit;
}


 $sql = "select * from cafe where curl = '{$curl}'";
 $go = $db -> prepare($sql);
 $go -> execute();
 $re = $go -> fetch();
if($curl==NULL) {
     echo "<script>alert('url을 입력해주세요.');</script>";
    echo "<script>history.back();</script>";
    exit();
}

elseif($re['curl']==$curl){
        echo '<script>
        alert("똑같은 url 주소가 있습니다.");</script>';
        echo "<script>history.back();</script>";
        exit;
    }

              
   $sql = "insert into cafe set cname='{$_POST['cname']}', curl='{$curl}',cexp='{$cexp}',cadmin='{$cadmin}'";
    $go = $db -> prepare($sql);
    $go->execute();

    echo "<script>alert('생성완료');location.href='./index.php'</script>";
?>