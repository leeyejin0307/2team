<?php
    include '../db_con.php';
    session_start();
    if(!isset($_SESSION['id'])) {
        echo "<script>alert('로그인을 해주세요.');location.href='../login.php';</script>";
        exit;
    }
    $curl = $_GET['curl'];

    //$sql = "select * from board where curl = '{$cname}'";
    //$go = $db -> prepare($sql);
    //$go->execute();
    //$re = $go -> fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/index.css">
</head>
<body>
    <div id="wrap">
        <header>
            <a href="./cafe_write.php"><button><i class="large material-icons">edit</i></button></a>
        </header>
        <section>
            <article class="board">
                <?php
                    //while($re = $go -> fetch()){
?>
                    <table class="tb">
                        <tr>
                            <td align="left" colspan="2">카테고리</td>
                        </tr>
                        <tr height="100">
                            <td colspan="2">제목</td>
                        </tr>
                        <tr>
                           <td align="left">날짜</td>
                            <td align="right">이예진</td>
                        </tr>
                        <tr>
                            <td colspan="2"><div id="hr"></div></td>
                        </tr>
                        <tr height="200" >
                            <td colspan="2"><pre>본문</pre></td>
                        </tr>
                    </table>
                    <?php
           // }
?>
            </article>
        </section>
        <aside>
            <?php
                  $sql = "select * from cafe where curl = '{$curl}'";
                $go = $db -> prepare($sql);
                $go->execute();
                $re = $go -> fetch();

                $sql2 = "select count(*) from cafejoin where curl = '{$curl}' and allow = '{1}'";
                //멤버수 구하고 싶다...
                $go2 = $db -> prepare($sql);
                $go2 -> execute();
                $re2 = $go2 -> fetch();

                
            ?>
            <div class="cover">
                <?php
                    if($re['cbenner']==NULL){
                ?>
               <img src="http://placehold.it/300x300" alt="corver">
                <?php
                    }
                ?>
                <p><?=$re['cname']?></p>
            </div>
            <?php
                    if($_SESSION['id']!=$re['cadmin']){
            ?>
            <a href="apply.php?curl=<?=$curl?>"><button>가입신청</button></a>
            <?php
                    }
            ?>
            <div class="info">
                <div>
                    <p><?=$re['cexp']?></p>
                </div>
                <div>
                    <p>멤버 <?=$re2[0]?>| 리더 <?=$re['cadmin']?></p><!--멤버수, 리더정보-->
                </div>
            </div>
            <div class="category">
               <span>CATEGORY</span>
                <ul>
                    <li><a href="">전체글 보기</a></li>
                    
                </ul>
            </div>
        </aside>
        <footer>
            
        </footer>
    </div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>

    var wi = $(".cover").width();
    var he = $(".cover").height();
    var winwi = $(window).height();
    
    $("#wrap").height(winwi);
    $(".cover > img").width(wi).height(he-60);
    
    
</script>