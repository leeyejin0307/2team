<?php
    session_start();
    if(!isset($_SESSION['id'])) {
        echo "<script>alert('로그인을 해주세요.');location.href='../login.php';</script>";
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/wrtie.css">
</head>
<body>
    <div id="wrap">
        <header>
           
        </header>
        <section>
            <article class="board">
                <form action="" method="post">
                    <table class="tb">
                      <tr>
                          <td><input type="text" name="title" id="title" placeholder="TITLE"></td>
                          <td align="right"> <a href=""><button><i class="large material-icons">edit</i></button></a></td>
                      </tr>
                      <tr>
                          <td colspan="2"><textarea name="content" id="content" cols="80" rows="30" style="resize:none" placeholder="CONTENT"></textarea></td>
                      </tr>
                    </table>
                </form>
            </article>
        </section>
        <aside>
            <div class="cover">
               <img src="http://placehold.it/300x300" alt="corver">
                <p>카페 이름</p>
            </div>
            <a href=""><button>가입신청</button></a>
            <div class="info">
                <div>
                    <p>카페설명</p>
                </div>
                <div>
                    <p>멤버 | 리더</p><!--멤버수, 리더정보-->
                </div>
            </div>
            <div class="category">
               <span>CATEGORY</span>
                <ul>
                    <li><a href="">전체글 보기</a></li>
                    
                </ul>
            </div>
        </aside>
        <footer>
            
        </footer>
    </div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>

    var wi = $(".cover").width();
    var he = $(".cover").height();
    var winwi = $(window).height();
    
    $("#wrap").height(winwi);
    $(".cover > img").width(wi).height(he-60);
    
    
</script>