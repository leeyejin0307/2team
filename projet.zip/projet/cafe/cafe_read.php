<?php
    session_start();
    if(!isset($_SESSION['id'])) {
        echo "<script>alert('로그인을 해주세요.');location.href='../login.php';</script>";
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./css/read.css">
</head>
<body>
    <div id="wrap">
        <header>
            <h1 class="logo"></h1>
        </header>
        <section>
            <article class="board">
                <table class="tb">
                    <tr>
                        <td align="left" colspan="2">카테고리</td>
                    </tr>
                    <tr height="100">
                        <td colspan="2">제목</td>
                    </tr>
                    <tr>
                       <td align="left">날짜</td>
                        <td align="right">이예진 </td>
                    </tr>
                    <tr>
                        <td colspan="2"><div id="hr"></div></td>
                    </tr>
                    <tr height="300" >
                        <td colspan="2"><pre>본문</pre></td>
                    </tr>
                </table>
                <form action="">
                    <table class="comment">
                       <tr>
                           <td align="center">이름</td>
                           <td align="center"><input type="text"></td>
                           <td align="right"><button type="submit" > <i class="large material-icons">check</i></button><br></td>
                       </tr>
                       
                        <tr>
                            <td rowspan="2" align="center">이미지</td>
                            <td>이름</td>
                            <td align="right">수정 삭제</td>
                        </tr>
                        <tr>
                            <td colspan="3" align="left">내용</td>
                        </tr>
                    </table>
                </form>
            </article>
        </section>
        <aside>
            <div class="cover">
               <img src="http://placehold.it/300x300" alt="corver">
                <p>카페 이름</p>
            </div>
            <a href=""><button>가입신청</button></a>
            <div class="info">
                <div>
                    <p>카페설명</p>
                </div>
                <div>
                    <p>멤버 | 리더</p><!--멤버수, 리더정보-->
                </div>
            </div>
            <div class="category">
               <span>CATEGORY</span>
                <ul>
                    <li><a href="">전체글 보기</a></li>
                    
                </ul>
            </div>
        </aside>
        <footer>
            
        </footer>
    </div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>

    var wi = $(".cover").width();
    var he = $(".cover").height();
    
    $(".cover > img").width(wi).height(he-60);
    
    
</script>