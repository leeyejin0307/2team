<?php
include('db_con.php');
$id = $_POST['id'];
$pw = $_POST['pw'];
$name = $_POST['name'];
$re_pw = $_POST['re_pw'];
$email = $_POST['email'];
$id = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $id);
$pw = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $pw);
$name = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $name);
$re_pw = preg_replace("/[ #\&\+\-%@=\/\\\:;,\.'\"\^`~\_|\!\?\*$#<>()\[\]\{\}]/i", "", $re_pw);
if(empty($id) || empty($pw)||empty($name)||empty($re_pw) || empty($email)) {
    echo "<script>alert('모두 입력해주세요.');</script>";
    echo "<script>history.back();</script>";
	exit;
}
else if( $pw!=$re_pw ) {
	 echo "<script>alert('비밀번호가 일치하지 않습니다.');</script>";
    echo "<script>history.back();</script>";
	exit;
}
else {
$query = "SELECT * from user";
$last = $db->query($query);
$last->setFetchMode(PDO::FETCH_ASSOC);
while($row= $last->fetch()){
    if($id==$row['id'] || $email==$row['email']) {
	 echo "<script>alert('똑같은 아이디나 이메일이 존재합니다..');</script>";
    echo "<script>history.back();</script>";
	exit;
   }
 }
}
$hash_pw = hash('sha512',$pw);
//$query = "INSERT into user(id,pw,email,name) VALUES('admin','admin','admin@naver.com','admin')";
$query = "INSERT INTO user(id,pw,email,name) VALUES('$id','$hash_pw','$email','$name')";
$signup = $db->exec($query);
 echo "<script>alert('회원가입 완료.');</script>";
echo "<script>location.href='index.php';</script>";
?>