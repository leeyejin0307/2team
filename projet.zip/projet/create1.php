<?php
    session_start();
    if(!isset($_SESSION['id'])){
        echo '<script>
        alert("로그인을 하십시오.");</script>';
        echo "<script>location.href='index.php'</script>";
        exit(); 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>create cafe</title>
    <script  src="http://code.jquery.com/jquery-latest.min.js"></script>

</head>
<body>
   <form action="create.php" method="POST">
 <input type="hidden" name ="cadmin" maxlength="100" value="<?=$_SESSION['id']?>"><br>
    cafe name: </br><input type="text" name ="cname" maxlength="200"><br>
    cafe exprain: </br><input type="text" name ="cexp" maxlength="100"><br>
    cafe url: </br><input type="text" name ="curl" maxlength="100"><br>
    <input type="submit" value="생성"/>
    </form>
</body>
</html>
